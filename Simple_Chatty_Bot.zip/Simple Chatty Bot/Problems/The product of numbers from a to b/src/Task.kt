

fun main(args: Array<String>) {
    for (i in 11 downTo 10){
        print(i)
    }
}
